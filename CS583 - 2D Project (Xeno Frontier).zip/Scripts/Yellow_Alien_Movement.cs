using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Yellow_Alien_Movement : AlienFollowPlayer
{

}
