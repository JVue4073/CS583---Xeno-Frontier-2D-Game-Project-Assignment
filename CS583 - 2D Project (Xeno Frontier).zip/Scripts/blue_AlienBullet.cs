using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IblueAlienBulletDamage
{
    void blueAlienBulletTakeDamage(int amount);
}

public class blue_AlienBullet : MonoBehaviour
{
    public GameObject blueAlien_bulletHitEffect; // Effect to show on hit
    public int blue_AlienBulletDamageAmount = 10; // Damage amount

    void OnCollisionEnter2D(Collision2D blueAlien_BulletCollision)
    {
        if (blueAlien_BulletCollision.gameObject.CompareTag("player_Ship") || blueAlien_BulletCollision.gameObject.CompareTag("Space Station"))
        {
            // Create a hit effect
            GameObject effect = Instantiate(blueAlien_bulletHitEffect, transform.position, Quaternion.identity);
            // Play laser explosion sound
            SoundManager.Instance.PlayBlueAlienFireExplosionSound();
            Destroy(effect, 1.4f); // Destroy the hit effect after 1.4 seconds

            // Check if the collided object implements IblueAlienBulletDamage
            IblueAlienBulletDamage blueAlien_damageable = blueAlien_BulletCollision.gameObject.GetComponent<IblueAlienBulletDamage>();
            if (blueAlien_damageable != null)
            {
                blueAlien_damageable.blueAlienBulletTakeDamage(blue_AlienBulletDamageAmount);
            }

            // Destroy the bullet on impact
            Destroy(gameObject);
        }
    }
}
