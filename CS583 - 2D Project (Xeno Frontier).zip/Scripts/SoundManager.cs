using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance;

    [Header("Audio Clips")]
    public AudioClip laserFireSound;
    public AudioClip laserExplosionSound;
    public AudioClip homingMissileSound;
    public AudioClip homingMissileExplosionSound;
    public AudioClip playerDeathSound;

    public AudioClip blueAlienFireSound;
    public AudioClip blueAlienFireExplosionSound;

    public AudioClip redAlienFireSound;
    public AudioClip redAlienFireExplosionSound;

    public AudioClip droidFireSound;
    public AudioClip droidDeathSound;

    private AudioSource audioSource;

    private void Awake()
    {
        // Singleton pattern to ensure only one instance of SoundManager
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // Keep it across scenes
        }
        else
        {
            Destroy(gameObject);
        }

        audioSource = gameObject.AddComponent<AudioSource>();
    }

    // Laser Sounds
    public void PlayLaserFireSound()
    {
        PlaySound(laserFireSound);
    }

    public void PlayLaserExplosionSound()
    {
        PlaySound(laserExplosionSound);
    }

    // Alien Sounds
    public void PlayBlueAlienFireSound()
    {
        PlaySound(blueAlienFireSound);
    }

    public void PlayBlueAlienFireExplosionSound()
    {
        PlaySound(blueAlienFireExplosionSound);
    }

    // Alien Sounds
    public void PlayRedAlienFireSound()
    {
        PlaySound(redAlienFireSound);
    }

    public void PlayRedAlienFireExplosionSound()
    {
        PlaySound(redAlienFireExplosionSound);
    }

    // Droid Sounds
    public void PlayDroidFireSound()
    {
        PlaySound(droidFireSound);
    }

    public void PlayDroidDeathSound()
    {
        PlaySound(droidDeathSound);
    }

    // Helper method to play a sound
    public void PlaySound(AudioClip clip)
    {
        if (clip != null)
        {
            audioSource.PlayOneShot(clip);
        }
        else
        {
            Debug.LogWarning("AudioClip is null.");
        }
    }
}
