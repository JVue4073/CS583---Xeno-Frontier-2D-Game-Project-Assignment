using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Yellow_Alien_Spawner : MonoBehaviour
{
    public GameObject yellowAlien_Prefab; // Make sure to assign this in the Inspector

    private float minSpawnTime = 8f; // Set your desired minimum spawn time
    private float maxSpawnTime = 16f; // Set your desired maximum spawn time
    private float timeUntilSpawn;

    private int totalYellowAliensToSpawn = 6;
    private int aliensSpawned = 0;

    void Awake()
    {
        SetTimeUntilSpawn();
    }

    void Update()
    {
        if (aliensSpawned < totalYellowAliensToSpawn)
        {
            timeUntilSpawn -= Time.deltaTime;

            if (timeUntilSpawn <= 0)
            {
                Instantiate(yellowAlien_Prefab, transform.position, Quaternion.identity);
                aliensSpawned++;
                SetTimeUntilSpawn();
            }
        }
    }

    private void SetTimeUntilSpawn()
    {
        timeUntilSpawn = Random.Range(minSpawnTime, maxSpawnTime);
    }
}
