using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Droid_Health : DamageableEntity, ILaserDamage, IhomingMissileDamage
{
    float droidHP, droidMaxHP = 120f;
    public GameObject homingMissilePowerUpPrefab;
    public int droidPoints = 150; // Points awarded for destroying the droid ship

    void Start()
    {
        droidHP = droidMaxHP;
    }

    public void TakeDamage(int damageAmount)
    {
        droidHP -= damageAmount;

        if (droidHP <= droidMaxHP * 0.2f)
        {
            BlinkEffect();
        }

        if (droidHP <= 0)
        {
            DroidDie();
        }
    }

    void DroidDie()
    {
        // Drop Powerup
        if (homingMissilePowerUpPrefab != null)
        {
            // Instantiate the power-up at the droid's position
            Instantiate(homingMissilePowerUpPrefab, transform.position, Quaternion.identity);
        }

        Destroy(gameObject);
    }
}
