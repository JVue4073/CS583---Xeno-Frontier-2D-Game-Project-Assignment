using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Red_Alien_Spawner : MonoBehaviour
{
    public GameObject redAlien_Prefab; // Make sure to assign this in the Inspector

    private float minSpawnTime = 10f; // Set your desired minimum spawn time
    private float maxSpawnTime = 30f; // Set your desired maximum spawn time
    private float timeUntilSpawn;

    private int totalRedAliensToSpawn = 8;
    private int aliensSpawned = 0;

    void Awake()
    {
        SetTimeUntilSpawn();
    }

    void Update()
    {
        if (aliensSpawned < totalRedAliensToSpawn)
        {
            timeUntilSpawn -= Time.deltaTime;

            if (timeUntilSpawn <= 0)
            {
                Instantiate(redAlien_Prefab, transform.position, Quaternion.identity);
                aliensSpawned++;
                SetTimeUntilSpawn();
            }
        }
    }

    private void SetTimeUntilSpawn()
    {
        timeUntilSpawn = Random.Range(minSpawnTime, maxSpawnTime);
    }
}
