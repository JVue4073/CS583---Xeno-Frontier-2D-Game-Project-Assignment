using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Droid_Enemy : MonoBehaviour
{
    public GameObject enemyDroid_Prefab; // Make sure to assign this in the Inspector

    private float minSpawnTime = 25f; // Set your desired minimum spawn time
    private float maxSpawnTime = 50f; // Set your desired maximum spawn time
    private float timeUntilSpawn;

    private int totalEnemyDroidsToSpawn = 1;
    private int droidsSpawned = 0;

    void Awake()
    {
        SetTimeUntilSpawn();
    }

    void Update()
    {
        if (droidsSpawned < totalEnemyDroidsToSpawn)
        {
            timeUntilSpawn -= Time.deltaTime;

            if (timeUntilSpawn <= 0)
            {
                Instantiate(enemyDroid_Prefab, transform.position, Quaternion.identity);
                droidsSpawned++;
                SetTimeUntilSpawn();
            }
        }
    }

    private void SetTimeUntilSpawn()
    {
        timeUntilSpawn = Random.Range(minSpawnTime, maxSpawnTime);
    }
}
