using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; // Make sure to include the TextMeshPro namespace

public class ScoreManager : MonoBehaviour
{
    [Header("Dynamic")]
    public int score = 0;
    public TextMeshProUGUI uiText; // Reference to the UI TextMeshPro element

    void Start()
    {
        uiText = GetComponent<TextMeshProUGUI>();
    }

    public void AddScore(int points)
    {
        score += points;
        Debug.Log("Score: " + score);
        UpdateScoreUI(); // Update the UI whenever the score changes
    }

    public int GetScore()
    {
        return score;
    }

    private void UpdateScoreUI()
    {
        uiText.text = score.ToString("#,0");
    }
}
