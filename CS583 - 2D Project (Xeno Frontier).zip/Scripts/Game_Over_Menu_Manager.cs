using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Game_Over_Menu_Manager : MonoBehaviour
{
    // Restart the game by loading the next scene (or the current one, depending on your setup)
    public void RestartGame()
    {
        SceneManager.LoadScene("XenoFrontierGame");
    }

    // Go to the Main Menu scene
    public void ReturnToMainMenu()
    {
        SceneManager.LoadSceneAsync("MainMenu");
    }
    
    // Quit the game
    public void QuitGame()
    {
        Application.Quit(); // Quit the application in a built version
    }
}
