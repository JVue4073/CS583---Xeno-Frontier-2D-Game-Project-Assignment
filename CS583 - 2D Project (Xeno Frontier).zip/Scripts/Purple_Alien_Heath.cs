using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Purple_Alien_Heath : MonoBehaviour, ILaserDamage, IhomingMissileDamage
{
    float alienPurple_HP, alienPurple_MaxHP = 1000f;
    void Start()
    {
        alienPurple_HP = alienPurple_MaxHP;
    }

    public void TakeDamage(int damageAmount)
    {
        alienPurple_HP -= damageAmount;

        if (alienPurple_HP <= 0)
        {
            PurpleAlienDie();

            SceneManager.LoadScene("VictoryScreen");
        }
    }

    void PurpleAlienDie()
    {
        Destroy(gameObject);
    }
}
