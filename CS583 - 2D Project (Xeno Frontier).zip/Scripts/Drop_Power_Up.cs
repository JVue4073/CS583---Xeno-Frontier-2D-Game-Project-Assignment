using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drop_Power_Up : MonoBehaviour
{
    // Example method for when the power-up is collected
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the player collected the power-up
        if (other.CompareTag("player_Ship")) // Ensure the player has the correct tag
        {
            other.gameObject.GetComponent<Shooting>().hasHomingMissilePowerUp = true;
            Destroy(gameObject); // Destroy the power-up after collection
        }
    }
}
