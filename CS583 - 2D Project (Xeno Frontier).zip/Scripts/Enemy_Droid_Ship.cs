using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Droid_Ship : MonoBehaviour
{
    public Transform player;
    public float speed = 5f; // Ensure this is set to a reasonable value
    public Rigidbody2D rb;
    public float shootingRange = 10f; // Ensure this is a reasonable value
    public float lineOfSight = 15f; // Ensure this is a reasonable value
    public Transform droid_Firepoint; // Ensure this is assigned in the Inspector
    public GameObject bullet;
    public float fireRate = 1f; // Time between shots
    private float nextFireTime;
    private float droid_bulletForce = 20f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        player = GameObject.FindGameObjectWithTag("player_Ship").transform;
        nextFireTime = 0f; // Initialize next fire time
    }

    void Update()
    {
        if (player == null)
        {
            Debug.LogError("Player reference is not set!");
            return;
        }

        float distance = Vector2.Distance(transform.position, player.transform.position);
        Vector2 direction = (player.transform.position - transform.position).normalized;

        if (distance < lineOfSight)
        {
            MoveTowardsPlayer(direction);
            if (distance < shootingRange && Time.time >= nextFireTime)
            {
                Shoot(direction);
            }
        }
    }

    private void MoveTowardsPlayer(Vector2 direction)
    {
        transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90f;
        transform.rotation = Quaternion.Euler(Vector3.forward * angle);
    }

    private void Shoot(Vector2 direction)
    {
        if (droid_Firepoint == null)
        {
            Debug.LogError("Firepoint is not assigned!");
            return;
        }

        nextFireTime = Time.time + fireRate; // Update next fire time
        GameObject bulletInstance = Instantiate(bullet, droid_Firepoint.position, droid_Firepoint.rotation);
        Rigidbody2D bulletRb = bulletInstance.GetComponent<Rigidbody2D>();
        bulletRb.AddForce(droid_Firepoint.up * droid_bulletForce, ForceMode2D.Impulse);
    }
}