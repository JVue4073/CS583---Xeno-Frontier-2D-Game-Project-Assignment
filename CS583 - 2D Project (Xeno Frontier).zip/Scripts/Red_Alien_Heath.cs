using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Red_Alien_Health : DamageableEntity, ILaserDamage, IhomingMissileDamage
{
    float alienRed_HP, alienRed_MaxHP = 200f;
    public int redAlienPoints = 200; // Points awarded for destroying the droid ship

    void Start()
    {
        alienRed_HP = alienRed_MaxHP;
    }

    public void TakeDamage(int damageAmount)
    {
        alienRed_HP -= damageAmount;

        if (alienRed_HP <= alienRed_MaxHP * 0.2f) // Assuming 20 is near death
        {
            BlinkEffect();
        }

        if (alienRed_HP <= 0)
        {
            redAlienDie();
        }
    }

    void redAlienDie()
    {
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        // Notify the AlienSpawnerManager that an alien has been defeated
        AlienSpawnerManager spawnerManager = FindObjectOfType<AlienSpawnerManager>();
        if (spawnerManager != null)
        {
            spawnerManager.AlienDefeated();
        }
    }
}
