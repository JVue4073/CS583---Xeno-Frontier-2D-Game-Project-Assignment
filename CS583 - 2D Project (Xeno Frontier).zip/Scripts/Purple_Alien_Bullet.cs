using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IpurpleAlienBulletDamage
{
    void bossAlienBulletTakeDamage(int amount);
}

public class Purple_Alien_Bullet : MonoBehaviour
{
    public float bulletLife = 1f;  // Defines how long before the bullet is destroyed
    public float rotation = 0f;
    public float speed = 1f;
    public int purpleAlienBulletDamage = 15;
    public GameObject purpleAlien_BulletHitEffect;

    private Vector2 spawnPoint;
    private float timer = 0f;

    // Sound Effects
    public AudioClip bulletSound; // Sound effect for the bullet
    public AudioClip hitSound;     // Sound effect for when it hits

    // Start is called before the first frame update
    public void Start()
    {
        spawnPoint = new Vector2(transform.position.x, transform.position.y);

        // Play the bullet sound when the bullet is instantiated
        if (bulletSound != null)
        {
            SoundManager.Instance.PlaySound(bulletSound);
        }
        else
        {
            Debug.LogWarning("Bullet sound clip is not assigned.");
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (timer > bulletLife) Destroy(this.gameObject);
        timer += Time.deltaTime;
        transform.position = Movement(timer);
    }

    private Vector2 Movement(float timer)
    {
        // Moves right according to the bullet's rotation
        float x = timer * speed * transform.right.x;
        float y = timer * speed * transform.right.y;
        return new Vector2(x + spawnPoint.x, y + spawnPoint.y);
    }

    public void OnCollisionEnter2D(Collision2D purpleAlien_bulletCollision)
    {
        // Check if the collided object has the "Player" tag
        if (purpleAlien_bulletCollision.gameObject.CompareTag("player_Ship") || purpleAlien_bulletCollision.gameObject.CompareTag("Space Station"))
        {
            // Instantiate the explosion effect at the bullet's position
            GameObject effect = Instantiate(purpleAlien_BulletHitEffect, transform.position, Quaternion.identity);
            Destroy(effect, 0.7f); // Adjust duration as necessary

            IpurpleAlienBulletDamage bullet_damageable = purpleAlien_bulletCollision.gameObject.GetComponent<IpurpleAlienBulletDamage>();
            if (bullet_damageable != null)
            {
                bullet_damageable.bossAlienBulletTakeDamage(purpleAlienBulletDamage); // Deal damage
            }

            // Play hit sound
            if (hitSound != null)
            {
                SoundManager.Instance.PlaySound(hitSound);
            }
            else
            {
                Debug.LogWarning("Hit sound clip is not assigned.");
            }

            // Destroy the bullet
            Destroy(gameObject);
        }
    }
}
