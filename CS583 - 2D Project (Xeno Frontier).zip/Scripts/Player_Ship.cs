using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Cryptography;
using UnityEngine;

public class Player_Ship : MonoBehaviour
{
    // Health system using a peg system
    //private const int MAX_HEALTH = 32;
    //private int currentHealth;
    
    // Ship Game Characteristics
    private Rigidbody2D rb;                    // Player Ship
    public Camera cam;

    //**
    //Might put this in another script to handle sub-weapon mechanics.
    //private float subWeaponChargeTime = 5.0f; // Time to fully charge sub-weapon
    //private float chargeProgress = 0.0f;      // IDK what this is until later....
    //private bool isCharging = false;          // For charging sub-weapon
    //public GameObject subWeapon;        // Ship sub weapon
    //
    
    float speed = 10.0f;                      // Ship move speed
    Vector2 mousePos;                         // Allows player to aim with mouse
    Vector2 movement;

    // Power-up collection
    private List<GameObject> powerUps;

    void Start()
    {
        //currentHealth = MAX_HEALTH;
        //powerUps = new List<GameObject>();
        rb = GetComponent<Rigidbody2D>(); // Get the Rigidbody2D component
    }

    void Update()
    {
        Move();
        //HandleSubWeaponShooting();
        //CheckHealth();
    }

    void Move()
    {
        // Basic movement logic (using arrow keys or WASD keys)
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        // Use the mouse to aim
        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);
        
        // Moves the ship while aiming with mouse
        rb.MovePosition(rb.position + movement * speed * Time.fixedDeltaTime);
        Vector2 lookDir = mousePos - rb.position;
        float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
        rb.rotation = angle;
    }

    //void HandleSubWeaponShooting()
    //{
    //    if (Input.GetButtonDown("Fire2")) // Sub-weapon activation
    //    {
    //        if (!isCharging)
    //        {
    //            StartChargingSubWeapon();
    //        }
    //    }

    //    if (Input.GetButtonUp("Fire2")) // Release sub-weapon
    //    {
    //        FireSubWeapon();
    //    }
    //}

    //void StartChargingSubWeapon()
    //{
    //    isCharging = true;
    //    chargeProgress = 0.0f;
    //    StartCoroutine(ChargeSubWeapon());
    //}

    //IEnumerator ChargeSubWeapon()
    //{
    //    while (chargeProgress < subWeaponChargeTime)
    //    {
    //        chargeProgress += Time.deltaTime;
    //        yield return null;
    //    }
    //    isCharging = false; // Charging complete
    //}

    //void FireSubWeapon()
    //{
    //    if (!isCharging) return;

    //    // Fire the charged sub-weapon
    //    Instantiate(subWeaponPrefab, transform.position, Quaternion.identity);
    //    // Reset charging
    //    isCharging = false;
    //    chargeProgress = 0.0f;
    //}

    //void CheckHealth()
    //{
    //    if (currentHealth <= 0)
    //    {
    //        // Handle player death (e.g., destroy the ship, show game over screen)
    //        Destroy(gameObject);
    //    }
    //}

    //public void TakeDamage(int damage)
    //{
    //    currentHealth -= damage;
    //    currentHealth = Mathf.Clamp(currentHealth, 0, MAX_HEALTH);
    //}

    //public void CollectPowerUp(GameObject powerUp)
    //{
    //    powerUps.Add(powerUp);
    //    // Implement logic for power-up effects (e.g., increase health, enhance weapons, etc.)
    //}
}