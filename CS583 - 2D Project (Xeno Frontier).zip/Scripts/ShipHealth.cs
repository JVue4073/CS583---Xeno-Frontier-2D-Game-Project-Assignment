using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ShipHealth : MonoBehaviour, IblueAlienBulletDamage, IHomingBulletDamage, IpurpleAlienBulletDamage, IdroidBulletDamage
{
    public int maxHealth = 100;
    private int currentHealth;
    public GameObject shipDeathExplosion;

    void Start()
    {
        currentHealth = maxHealth;
    }

    public void blueAlienBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void homingBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void droidBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void bossAlienBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    private IEnumerator GameOverDelay()
    {
        // Wait for a few seconds before transitioning
        yield return new WaitForSeconds(5f); // Adjust delay as needed
        SceneManager.LoadScene("GameOver");
    }

    private void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            if (shipDeathExplosion != null)
            {
                GameObject deathEffect = Instantiate(shipDeathExplosion, transform.position, transform.rotation);
                Destroy(deathEffect, 3.4f);
            }
            Destroy(gameObject);

            // Start the Game Over transition with delay
            StartCoroutine(GameOverDelay());

            // Load the Game Over scene
            SceneManager.LoadScene("GameOver");  // Make sure "GameOver" matches the exact name of your scene in Build Settings
        }
    }
}
