using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Yellow_Alien_Health : DamageableEntity, ILaserDamage, IhomingMissileDamage
{
    float alienYellow_HP, alienYellow_MaxHP = 120f;
    public int yellowAlienPoints = 150; // Points awarded for destroying the droid ship

    void Start()
    {
        alienYellow_HP = alienYellow_MaxHP;
    }

    public void TakeDamage(int damageAmount)
    {
        alienYellow_HP -= damageAmount;

        if (alienYellow_HP <= alienYellow_MaxHP * 0.2f) // Assuming 20 is near death
        {
            BlinkEffect();
        }

        if (alienYellow_HP <= 0)
        {
            yellowAlienDie();
        }
    }

    void yellowAlienDie()
    {
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        // Notify the AlienSpawnerManager that an alien has been defeated
        AlienSpawnerManager spawnerManager = FindObjectOfType<AlienSpawnerManager>();
        if (spawnerManager != null)
        {
            spawnerManager.AlienDefeated();
        }
    }
}
