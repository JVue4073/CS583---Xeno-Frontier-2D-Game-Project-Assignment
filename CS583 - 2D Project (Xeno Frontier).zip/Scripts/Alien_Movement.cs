using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienFollowPlayer : MonoBehaviour
{
    public Transform player;                // Reference to the player's position
    public float moveSpeed = 5f;            // Movement speed of the alien
    public float obstacleAvoidanceRange = 1f; // How far to check for obstacles ahead
    private Rigidbody2D rb;                 // Reference to the alien's Rigidbody2D

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        player = GameObject.FindGameObjectWithTag("player_Ship").transform; // Get the player reference by tag
    }

    void Update()
    {
        MoveTowardsPlayer();
    }

    void MoveTowardsPlayer()
    {
        // Get direction to the player
        Vector2 direction = (player.position - transform.position).normalized;

        // Cast a ray in the direction the alien is moving
        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, obstacleAvoidanceRange);

        // If the ray hits an object tagged as "Coll_Test" (e.g., asteroids)
        if (hit.collider != null && hit.collider.CompareTag("Coll_Test"))
        {
            // Modify direction to avoid the obstacle
            Vector2 avoidDirection = Vector2.Perpendicular(hit.normal); // Get a direction perpendicular to the obstacle
            rb.velocity = avoidDirection * moveSpeed; // Move around the obstacle
        }
        else
        {
            // Move the alien towards the player using Rigidbody2D velocity
            rb.velocity = direction * moveSpeed;
        }
    }
}

