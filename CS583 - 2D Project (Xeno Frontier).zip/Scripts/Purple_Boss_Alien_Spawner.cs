using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Purple_Boss_Alien_Spawner : MonoBehaviour
{
    public GameObject purpleBossAlienPrefab; // Assign this in the Inspector
    public static Purple_Boss_Alien_Spawner Instance;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SpawnBoss()
    {
        Instantiate(purpleBossAlienPrefab, transform.position, Quaternion.identity);
    }
}
