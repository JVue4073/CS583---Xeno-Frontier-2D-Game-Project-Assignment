using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaceStation_BaseHealth : MonoBehaviour
{
    float baseBarrierHealth, maxBarrierHealth = 800f;

    // Start is called before the first frame update
    void Start()
    {
        baseBarrierHealth = maxBarrierHealth;
    }

    // Update is called once per frame
    public void TakeDamage(int damageAmount)
    {
        baseBarrierHealth -= damageAmount;
        if (baseBarrierHealth <= 0)
        {
            baseBarrierDown();
        }

    }

    void baseBarrierDown()
    {
        Destroy(gameObject);
    }
}
