using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMovement : MonoBehaviour
{
    // Ship Game Characteristics
    public Rigidbody2D rb;                    // Player Ship
    public Camera cam;

    public float speed = 10.0f;               // Ship move speed
    Vector2 mousePos;                         // Allows player to aim with mouse
    Vector2 movement;

    void Update()
    {
        // Basic movement logic (using arrow keys or WASD keys)
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        // Use the mouse to aim
        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);
    }

    void FixedUpdate()
    {
        // Moves the ship while aiming with mouse
        rb.MovePosition(rb.position + movement * speed * Time.fixedDeltaTime);
        Vector2 lookDir = mousePos - rb.position;
        float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
        rb.rotation = angle;
    }
}
