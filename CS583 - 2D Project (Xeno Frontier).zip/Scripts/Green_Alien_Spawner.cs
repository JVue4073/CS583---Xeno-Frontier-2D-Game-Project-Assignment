using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Green_Alien_Spawner : MonoBehaviour
{
    public GameObject greenAlien_Prefab; // Make sure to assign this in the Inspector

    private float minSpawnTime = 2f; // Set your desired minimum spawn time
    private float maxSpawnTime = 16f; // Set your desired maximum spawn time
    private float timeUntilSpawn;

    private int totalGreenAliensToSpawn = 18;
    private int aliensSpawned = 0;

    void Awake()
    {
        SetTimeUntilSpawn();
    }

    void Update()
    {
        if (aliensSpawned < totalGreenAliensToSpawn)
        {
            timeUntilSpawn -= Time.deltaTime;

            if (timeUntilSpawn <= 0)
            {
                Instantiate(greenAlien_Prefab, transform.position, Quaternion.identity);
                aliensSpawned++;
                SetTimeUntilSpawn();
            }
        }
    }

    private void SetTimeUntilSpawn()
    {
        timeUntilSpawn = Random.Range(minSpawnTime, maxSpawnTime);
    }
}

