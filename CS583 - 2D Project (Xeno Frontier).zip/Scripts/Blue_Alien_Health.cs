using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blue_Alien_Health : DamageableEntity, ILaserDamage, IhomingMissileDamage
{
    float bluealien_HP, bluealien_MaxHP = 160f;

    void Start()
    {
        bluealien_HP = bluealien_MaxHP;
    }

    public void TakeDamage(int damageAmount)
    {
        bluealien_HP -= damageAmount;

        if (bluealien_HP <= bluealien_MaxHP * 0.2f)
        {
            BlinkEffect();
        }

        if (bluealien_HP <= 0)
        {
            BlueAlienDie();
        }
    }

    void BlueAlienDie()
    {
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        // Notify the AlienSpawnerManager that an alien has been defeated
        AlienSpawnerManager spawnerManager = FindObjectOfType<AlienSpawnerManager>();
        if (spawnerManager != null)
        {
            spawnerManager.AlienDefeated();
        }
    }
}
