using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Alien_Health : DamageableEntity, ILaserDamage, IhomingMissileDamage
{
    float alienHP, alienMaxHP = 100f;
    public int greenAlienPoints = 50; // Points awarded for destroying the droid ship

    void Start()
    {
        alienHP = alienMaxHP;
    }

    public void homingMissileTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void TakeDamage(int damageAmount)
    {
        alienHP -= damageAmount;

        if (alienHP <= alienMaxHP * 0.2f) // Assuming 20 is near death
        {
            BlinkEffect();
        }

        if (alienHP <= 0)
        {
            AlienDie();
        }
    }

    void AlienDie()
    {
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        // Notify the AlienSpawnerManager that an alien has been defeated
        AlienSpawnerManager spawnerManager = FindObjectOfType<AlienSpawnerManager>();
        if (spawnerManager != null)
        {
            spawnerManager.AlienDefeated();
        }
    }
}
