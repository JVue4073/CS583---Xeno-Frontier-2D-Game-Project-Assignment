using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienSpawnerManager : MonoBehaviour
{
    private int defeatedAlienCount = 0;

    // This method should be called whenever an alien is defeated.
    public void AlienDefeated()
    {
        defeatedAlienCount++;

        // Check if all 40 aliens have been defeated
        if (defeatedAlienCount >= 40)
        {
            // Spawn the boss alien
            Purple_Boss_Alien_Spawner.Instance.SpawnBoss();
        }
    }
}
