using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Red_Alien_Fire : MonoBehaviour
{
    public GameObject bullet;               // The bullet prefab to instantiate
    public Transform firePoint1;             // The point from which the bullets will be fired
    public float fireRate = 1f;              // Time between shots
    private float nextFireTime;              // Time until the next shot can be fired
    public Transform player;                 // Reference to the player's position

    void Start()
    {
        nextFireTime = 0f; // Initialize next fire time
        player = GameObject.FindGameObjectWithTag("player_Ship").transform; // Get the player reference by tag
    }

    void Update()
    {
        // Check if it's time to fire
        if (Time.time >= nextFireTime)
        {
            Fire();
        }
    }

    void Fire()
    {
        nextFireTime = Time.time + fireRate; // Update next fire time

        // Fire the bullet
        FireBullet(firePoint1.position, firePoint1.rotation);

        // Play laser fire sound
        SoundManager.Instance.PlayRedAlienFireSound();
    }

    void FireBullet(Vector2 position, Quaternion rotation)
    {
        // Instantiate the bullet
        GameObject bulletInstance = Instantiate(bullet, position, rotation);
        Rigidbody2D bulletRb = bulletInstance.GetComponent<Rigidbody2D>();
        bulletRb.AddForce(rotation * Vector2.up * 20f, ForceMode2D.Impulse); // Adjust bullet force as needed
    }
}

