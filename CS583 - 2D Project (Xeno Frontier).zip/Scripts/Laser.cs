using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ILaserDamage
{
    void TakeDamage(int amount);
}

public class Laser : MonoBehaviour
{
    public GameObject laserHitEffect;
    public int laser_damageAmount = 10;

    void OnCollisionEnter2D(Collision2D laserCollision)
    {

        if (laserCollision.gameObject.CompareTag("Alien") || laserCollision.gameObject.CompareTag("Droid") || laserCollision.gameObject.CompareTag("BossProjectile"))
        {
            GameObject effect = Instantiate(laserHitEffect, transform.position, Quaternion.identity);
            // Play laser explosion sound
            SoundManager.Instance.PlayLaserExplosionSound();
            Destroy(effect, 1.4f);

            // Check if the collided object implements ILaserDamage
            ILaserDamage damageable = laserCollision.gameObject.GetComponent<ILaserDamage>();
            if (damageable != null)
            {
                damageable.TakeDamage(laser_damageAmount); // Pass the damage amount
            }

            Destroy(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
