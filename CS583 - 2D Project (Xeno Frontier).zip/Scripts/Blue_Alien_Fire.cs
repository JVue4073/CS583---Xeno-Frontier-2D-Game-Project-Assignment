using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blue_Alien_Fire : MonoBehaviour
{
    public GameObject bullet;                 // The bullet prefab to instantiate
    public Transform firePoint1;              // The point from which the bullets will be fired
    public Transform firePoint2;              // The point from which the bullets will be fired
    public Transform firePoint3;              // The point from which the bullets will be fired
    public float fireRate;                    // Time between shots
    private float nextFireTime;              // Time until the next shot can be fired
    public Transform player;                 // Reference to the player's position
    public float bulletLifetime = 3f;         // Time before the bullet is destroyed (in seconds)

    void Start()
    {
        nextFireTime = 0f; // Initialize next fire time
        player = GameObject.FindGameObjectWithTag("player_Ship").transform; // Get the player reference by tag
    }

    void Update()
    {
        // Check if it's time to fire
        if (Time.time >= nextFireTime)
        {
            Fire();
        }
    }

    void Fire()
    {
        nextFireTime = Time.time + fireRate; // Update next fire time

        // Get direction to the player
        Vector2 directionToPlayer = (player.position - firePoint1.position).normalized;

        // Fire the three bullets
        FireBullet(firePoint1.position, Quaternion.FromToRotation(Vector2.up, directionToPlayer)); // Center bullet
        FireBullet(firePoint2.position, Quaternion.FromToRotation(Vector2.up, directionToPlayer + new Vector2(-0.5f, 0))); // Left bullet
        FireBullet(firePoint3.position, Quaternion.FromToRotation(Vector2.up, directionToPlayer + new Vector2(0.5f, 0))); // Right bullet

        // Play laser fire sound
        SoundManager.Instance.PlayBlueAlienFireSound();
    }

    void FireBullet(Vector2 position, Quaternion rotation)
    {
        // Instantiate the bullet
        GameObject bulletInstance = Instantiate(bullet, position, rotation);
        Rigidbody2D bulletRb = bulletInstance.GetComponent<Rigidbody2D>();
        bulletRb.AddForce(rotation * Vector2.up * 20f, ForceMode2D.Impulse); // Adjust bullet force as needed

        // Destroy the bullet after 'bulletLifetime' seconds
        Destroy(bulletInstance, bulletLifetime);
    }
}
