using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SpaceStationHealth : MonoBehaviour, IblueAlienBulletDamage, IHomingBulletDamage, IpurpleAlienBulletDamage, IdroidBulletDamage
{
    float baseStationHealth, maxStationHealth = 1250f;

    void Start()
    {
        baseStationHealth = maxStationHealth;
    }

    public void blueAlienBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void homingBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void droidBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void bossAlienBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    private IEnumerator GameOverDelay()
    {
        // Wait for a few seconds before transitioning
        yield return new WaitForSeconds(5f); // Adjust delay as needed
        SceneManager.LoadScene("GameOver");
    }

    public void TakeDamage(int damageAmount)
    {
        baseStationHealth -= damageAmount;
        if (baseStationHealth <= 0)
        {
            Destroy(gameObject);

            // Start the Game Over transition with delay
            StartCoroutine(GameOverDelay());

            // Load the Game Over scene
            SceneManager.LoadScene("GameOver");  // Make sure "GameOver" matches the exact name of your scene in Build Settings
        }
    }
}
