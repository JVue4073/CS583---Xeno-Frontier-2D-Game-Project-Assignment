using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    // Main Weapon system
    public GameObject mainWeaponPrefab;         // The Blue Ship Laser Prefab
    public Transform firePoint1, firePoint2;        // The Ship's firepoint 1 & 2
    public float bulletForce = 20f;
    public bool hasHomingMissilePowerUp = false;

    // Sub Weapon System
    // Need values for:
    // Firepoints for missiles
    // Uses a missiles prefab
    public GameObject subWeaponPrefab1;
    public Transform missileFirePoint1;

    void Update()
    {
        if (Input.GetButtonDown("Fire1")) // Main weapon: Fires lasers
        {
            ShootMainWeapon();
        }

        if (hasHomingMissilePowerUp == true)
        {
            if (Input.GetButtonDown("Fire2")) // Sub weapon: Fires homing missiles
            {
                FireHomingMissiles();
            }
        }
    }

    void ShootMainWeapon()
    {
        // Instantiate the main weapon projectile
        GameObject bullet1 = Instantiate(mainWeaponPrefab, firePoint1.position, firePoint1.rotation);
        GameObject bullet2 = Instantiate(mainWeaponPrefab, firePoint2.position, firePoint2.rotation);
        Rigidbody2D rb1 = bullet1.GetComponent<Rigidbody2D>();
        Rigidbody2D rb2 = bullet2.GetComponent<Rigidbody2D>();
        rb1.AddForce(firePoint1.up * bulletForce, ForceMode2D.Impulse);
        rb2.AddForce(firePoint2.up * bulletForce, ForceMode2D.Impulse);

        // Play laser fire sound
        SoundManager.Instance.PlayLaserFireSound();
    }

    private List<GameObject> GetEnemies()
    {
        // Find all enemies in the scene (adjust layer/tag as needed)
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Alien");
        List<GameObject> targetList = new List<GameObject>(enemies);
        return targetList;
    }

    // Method to fire homing missiles
    private void FireHomingMissiles()
    {
        // Get the list of targets
        List<GameObject> targets = GetEnemies();

        // Check if there are any targets available
        if (targets.Count == 0)
        {
            return; // Exit if no targets are available
        }

        // Fire from the single fire point (missileFirePoint1)
        for (int i = 0; i < targets.Count; i++)
        {
            // Instantiate the missile at the fire point
            GameObject missile = Instantiate(subWeaponPrefab1, missileFirePoint1.position, Quaternion.identity);

            // Set the target for homing
            HomingMissile homingMissile = missile.GetComponent<HomingMissile>();
            if (homingMissile != null)
            {
                homingMissile.SetTarget(targets[i]); // Set the target for homing
            }

            // Apply force to the missile to launch it towards the target
            Rigidbody2D rb = missile.GetComponent<Rigidbody2D>();
            Vector2 direction = (targets[i].transform.position - missileFirePoint1.position).normalized;
            rb.AddForce(direction * bulletForce, ForceMode2D.Impulse);
        }
    }
}