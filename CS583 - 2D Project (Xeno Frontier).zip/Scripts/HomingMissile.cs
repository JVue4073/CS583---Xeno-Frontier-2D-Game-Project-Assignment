using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IhomingMissileDamage
{
    void TakeDamage(int amount);
}

public class HomingMissile : MonoBehaviour
{
    private Transform target;
    public float speed = 5f;
    public float rotateSpeed = 200f;
    public GameObject homingMissileEffect;
    public int homingMissileDmg = 50;
    public float selfDestructTime = 5f; // Time after which the missile destroys itself if no target is found

    private float timeSinceTargetLost = 0f; // Timer for self-destruction when no target is found

    void Update()
    {
        // Check if there is no target
        if (target == null)
        {
            timeSinceTargetLost += Time.deltaTime; // Increase the timer when there's no target

            // If the missile has been without a target for too long, self-destruct
            if (timeSinceTargetLost >= selfDestructTime)
            {
                DestroyMissile();
            }
        }
        else
        {
            // Reset the self-destruct timer when a valid target is locked
            timeSinceTargetLost = 0f;

            // Calculate the direction to the target
            Vector2 direction = (Vector2)target.position - (Vector2)transform.position;
            float distance = direction.magnitude;

            // Normalize the direction for rotation and movement
            direction.Normalize();

            // Calculate the target rotation
            float targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion targetRotation = Quaternion.Euler(new Vector3(0, 0, targetAngle));

            // Smoothly rotate towards the target direction
            transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRotation, rotateSpeed * Time.deltaTime);

            // Move forward in the current direction
            transform.Translate(Vector2.up * speed * Time.deltaTime, Space.Self);
        }
    }

    void OnCollisionEnter2D(Collision2D homingMissile_Collision)
    {
        // Check if the collided object has the "Alien" tag
        if (homingMissile_Collision.gameObject.CompareTag("Alien"))
        {
            // Instantiate the explosion effect at the missile's position
            GameObject effect = Instantiate(homingMissileEffect, transform.position, Quaternion.identity);
            Destroy(effect, 1.4f);

            IhomingMissileDamage missile_damageable = homingMissile_Collision.gameObject.GetComponent<IhomingMissileDamage>();
            if (missile_damageable != null)
            {
                missile_damageable.TakeDamage(homingMissileDmg); // Deal damage
            }

            // Destroy the missile
            Destroy(gameObject);
        }
    }

    public void SetTarget(GameObject newTarget)
    {
        // Check if the new target is an enemy (could be multiple types of enemies)
        if (newTarget.CompareTag("Alien") || newTarget.CompareTag("Droid"))
        {
            target = newTarget.transform;
            timeSinceTargetLost = 0f; // Reset the self-destruct timer when a new target is set
        }
        else
        {
            Debug.LogWarning("Target is not a valid enemy!");
        }
    }

    // Method to destroy the missile (called when no target is found after a certain time)
    private void DestroyMissile()
    {
        // Optionally, you could trigger an explosion effect here as well
        GameObject effect = Instantiate(homingMissileEffect, transform.position, Quaternion.identity);
        Destroy(effect, 1.4f);

        Destroy(gameObject); // Destroy the missile
    }
}
