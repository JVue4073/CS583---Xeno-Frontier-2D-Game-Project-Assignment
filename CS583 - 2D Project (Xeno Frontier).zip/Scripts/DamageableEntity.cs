using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageableEntity : MonoBehaviour
{
    public Renderer entityRenderer; // Reference to the object's Renderer
    public Color damageColor = Color.red; // Color to use when damaged
    public float blinkDuration = 0.5f; // Total duration for the blink effect
    public int blinkCount = 5; // How many times to blink

    protected void BlinkEffect()
    {
        StartCoroutine(BlinkCoroutine());
    }

    private IEnumerator BlinkCoroutine()
    {
        for (int i = 0; i < blinkCount; i++)
        {
            entityRenderer.material.color = damageColor; // Change to damage color
            yield return new WaitForSeconds(blinkDuration / (blinkCount * 2));
            entityRenderer.material.color = Color.white; // Reset to original color
            yield return new WaitForSeconds(blinkDuration / (blinkCount * 2));
        }
    }
}

