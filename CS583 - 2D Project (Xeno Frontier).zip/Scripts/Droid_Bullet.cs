using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IdroidBulletDamage
{
    void droidBulletTakeDamage(int amount);
}

public class Droid_Bullet : MonoBehaviour
{
    public GameObject droid_bulletHitEffect;
    public int droid_bulletDamageAmount = 10;

    void OnCollisionEnter2D(Collision2D d_bulletCollision)
    {
        GameObject effect = Instantiate(droid_bulletHitEffect, transform.position, Quaternion.identity);
        Destroy(effect, 1.4f);

        // Check if the collided object implements ILaserDamage
        IdroidBulletDamage droid_damageable = d_bulletCollision.gameObject.GetComponent<IdroidBulletDamage>();
        if (droid_damageable != null)
        {
            droid_damageable.droidBulletTakeDamage(droid_bulletDamageAmount); // Pass the damage amount
        }

        Destroy(gameObject);
    }
}
