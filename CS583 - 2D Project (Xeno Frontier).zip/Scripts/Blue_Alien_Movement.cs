using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blue_Alien_Movement : MonoBehaviour
{
    public Transform player;                // Reference to the player's position
    public float moveSpeed;            // Movement speed of the alien
    public float obstacleAvoidanceRange; // How far to check for obstacles ahead
    public float oscillationDistance;   // Maximum distance to move left and right
    public float oscillationSpeed;      // Speed of the oscillation
    public float followDistance;        // Distance to keep from the player

    private Rigidbody2D rb;                 // Reference to the alien's Rigidbody2D
    private float oscillationTime;           // Time variable for oscillation

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        player = GameObject.FindGameObjectWithTag("player_Ship").transform; // Get the player reference by tag
    }

    void Update()
    {
        MoveTowardsPlayer();
    }

    void MoveTowardsPlayer()
    {
        // Get the direction to the player
        Vector2 directionToPlayer = (player.position - transform.position).normalized;

        // Calculate the target position to follow the player while maintaining a distance
        Vector2 targetPosition = (Vector2)player.position - directionToPlayer * followDistance;

        // Calculate the oscillation offset based on sine wave
        oscillationTime += Time.deltaTime * oscillationSpeed;
        float oscillationOffset = Mathf.Sin(oscillationTime) * oscillationDistance;

        // Update the target position with the oscillation effect
        targetPosition += new Vector2(oscillationOffset, 0);

        // Cast a ray in the direction the alien is moving
        RaycastHit2D hit = Physics2D.Raycast(transform.position, directionToPlayer, obstacleAvoidanceRange);

        // If the ray hits an object tagged as "Coll_Test" (e.g., asteroids)
        if (hit.collider != null && hit.collider.CompareTag("Coll_Test"))
        {
            // Modify direction to avoid the obstacle
            Vector2 avoidDirection = Vector2.Perpendicular(hit.normal); // Get a direction perpendicular to the obstacle
            rb.velocity = avoidDirection * moveSpeed; // Move around the obstacle
        }
        else
        {
            // Move towards the calculated target position
            Vector2 movement = Vector2.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
            rb.MovePosition(movement);
        }
    }
}

