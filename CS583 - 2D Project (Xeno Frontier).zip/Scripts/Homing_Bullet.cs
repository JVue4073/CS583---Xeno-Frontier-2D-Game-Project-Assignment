using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IHomingBulletDamage
{
    void homingBulletTakeDamage(int amount);
}

public class Homing_Bullet : MonoBehaviour
{
    public float speed = 5f; // Speed of the bullet
    public GameObject redAlien_bulletHitEffect; // Effect to show on hit
    public int homingBulletDamageAmount = 10; // Damage amount
    private Rigidbody2D rb;

    public Transform target;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        target = GameObject.FindGameObjectWithTag("player_Ship").transform;
    }

    void FixedUpdate()
    {
        //transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
        // Calculate direction to target
        Vector2 direction = (target.position - transform.position).normalized;

        // Add some randomness to the direction
        float randomOffset = Random.Range(-0.2f, 0.2f); // Adjust the range as needed
        direction = Quaternion.Euler(0, 0, randomOffset) * direction;

        // Move towards the adjusted direction
        rb.velocity = direction * speed;
    }

    void OnCollisionEnter2D(Collision2D redAlien_BulletCollision)
    {
        if (redAlien_BulletCollision.gameObject.CompareTag("player_Ship") || redAlien_BulletCollision.gameObject.CompareTag("Space Station"))
        {
            // Existing code for player ship hit
            HandlePlayerShipHit(redAlien_BulletCollision);
        }
        else if (redAlien_BulletCollision.gameObject.CompareTag("ShipLaser"))
        {
            // Destroy the homing bullet on laser hit
            Destroy(gameObject);
            SoundManager.Instance.PlayRedAlienFireExplosionSound();
        }
    }

    private void HandlePlayerShipHit(Collision2D collision)
    {
        GameObject effect = Instantiate(redAlien_bulletHitEffect, transform.position, Quaternion.identity);
        SoundManager.Instance.PlayRedAlienFireExplosionSound();
        Destroy(effect, 0.7f); // Destroy the hit effect after 0.5 seconds

        IHomingBulletDamage redAlien_damageable = collision.gameObject.GetComponent<IHomingBulletDamage>();
        if (redAlien_damageable != null)
        {
            redAlien_damageable.homingBulletTakeDamage(homingBulletDamageAmount); // Pass the damage amount
        }

        // Destroy the bullet on impact
        Destroy(gameObject);
    }
}
