using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaceStationShieldHealth : MonoBehaviour, IblueAlienBulletDamage, IHomingBulletDamage, IpurpleAlienBulletDamage, IdroidBulletDamage
{
    float baseStationShieldHealth, maxStationShieldHealth = 500f;

    void Start()
    {
        baseStationShieldHealth = maxStationShieldHealth;
    }

    public void blueAlienBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void homingBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void droidBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    public void bossAlienBulletTakeDamage(int damage)
    {
        TakeDamage(damage);
    }

    // Update is called once per frame
    public void TakeDamage(int damageAmount)
    {
        baseStationShieldHealth -= damageAmount;
        if (baseStationShieldHealth <= 0)
        {
            Destroy(this.gameObject);
        }
    }
}
